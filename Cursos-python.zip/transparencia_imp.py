import requests
import util
from pprint import pprint
import csv
from collections import OrderedDict

CODIGO_IFS = "26423"
URL_BASE = "http://www.transparencia.gov.br"
END_POINT_SERVIDORES = "/api-de-dados/servidores"
PARAMETROS_BUSCA_IFS = {"orgaoServidorExercicio": CODIGO_IFS}


def montar_url(end_point):
  return "{}{}".format(URL_BASE, end_point)

def montar_url_servidores_ifs():
  return montar_url(END_POINT_SERVIDORES)

def executar_consulta(url, params={}):
  data = requests.get(url, params=params)
  return data.json()

def teste_consulta():
  params = {
    "id": "28710343",
    "orgaoServidorExercicio": CODIGO_IFS,
    "pagina": 1
  }

  url_consulta_servidor = montar_url_servidores_ifs()
  dados = executar_consulta(url_consulta_servidor, params)

  print(dados)


def extrair_dados_servidores(resposta_api):
  for dado in resposta_api:
    try:
      servidor = dado["servidor"]
      ficha = dado["fichasCargoEfetivo"][0]

      serv = OrderedDict()
      serv["id"] = servidor["id"]
      serv["nome"] = servidor["pessoa"]["nome"]
      serv["situacao_servidor"] = ficha["situacaoServidor"]
      serv["unidade_exercicio"] = ficha["uorgExercicio"]
      serv["cargo"] = ficha["cargo"]
      serv["classe_cargo"] = ficha["classeCargo"]
      serv["padrao_cargo"] = ficha["padraoCargo"]

      yield serv

    except Exception as e:
      print(e)
    finally:
      pass

def listar_servidores():
  params = dict(PARAMETROS_BUSCA_IFS) #Criando uma cópia de PARAMETROS_BUSCA_IFS
  params["pagina"] = 1 #Buscando a primeira página

  url = montar_url_servidores_ifs()
  dados = executar_consulta(url, params)

  return extrair_dados_servidores(dados)


def exportar_servidores_para_csv(servidores, nome_arquivo):
  with open(nome_arquivo, "w") as f:
    writer = csv.writer(f, delimiter=";")
    for servidor in servidores:
      writer.writerow(servidor.values())



def main():
  servidores = listar_servidores()
  exportar_servidores_para_csv(servidores, "./servidores.csv")

