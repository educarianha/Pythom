import transparencia_imp

transparencia_imp.main()