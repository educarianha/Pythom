import json

def exportar_json(dados, nome_arquivo):
  with open(nome_arquivo, "w") as f:
    json.dump(dados, f)



  

  